package arrays;

public class Frequency {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		for(int i=0;i<ar.length;i++) {
			int count=1;
			for(int j=i+1;j<ar.length;j++) {
				if(ar[i]==ar[j]) {
					count++;
					ar[j]=0;
					
				}
			}
			if(ar[i]!=0)
			System.out.println(ar[i]+"--------->"+count);	
			
		}
	}

}
