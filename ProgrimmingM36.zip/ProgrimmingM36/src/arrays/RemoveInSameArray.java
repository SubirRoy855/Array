package arrays;

import java.util.Scanner;

public class RemoveInSameArray {

	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the index value: ");
		int index = sc.nextInt();
		isRemoveElement(ar, index);
		sc.close();
	}

	public static void isRemoveElement(int[] ar, int index) {

		int j = index;

		if (index < 0 || index > ar.length)
			System.out.println("invalid index");

		else {
			while (j < ar.length - 1) {
				ar[j] = ar[j + 1];
				j++;
			}
			ar[ar.length - 1] = 0;
			for (int i = 0; i < ar.length - 1; i++) {
				System.out.print(ar[i] + " ");
			}

		}

	}

}
