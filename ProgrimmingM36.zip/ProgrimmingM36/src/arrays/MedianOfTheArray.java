package arrays;

public class MedianOfTheArray {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int median = 0;

		if (ar.length % 2 == 0) {
			int sum = ar[ar.length / 2 - 1] + ar[ar.length / 2] ;
			median=sum/2;
		} else
			median = ar[ar.length / 2];

		System.out.println("median is: "+median);

	}

}
