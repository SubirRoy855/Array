package arrays;

public class Excpation {
	public static void main(String[] args) {
		double[] a=new double[4];
		a[0]=10.55;
		a[1]=20.25;
		a[2]=86.36;
		a[3]=152.595;
		System.out.println(a[0]);
		System.out.println(a[1]);
		
		System.out.println(a[2]);
		System.out.println(a[3]);
		
		
		
		
		System.out.println(a[4]);
		
	}

}
