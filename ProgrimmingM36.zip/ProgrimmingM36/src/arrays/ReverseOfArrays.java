package arrays;

import java.util.Scanner;

public class ReverseOfArrays {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of arry");
		int n = sc.nextInt();

		int[] a = new int[n];
		System.out.println("enter the array values");
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("-----------------------");
		for (int i = a.length - 1; i >= 0; i--) {
			System.out.println(a[i]);
		}
		sc.close();
	}

}
