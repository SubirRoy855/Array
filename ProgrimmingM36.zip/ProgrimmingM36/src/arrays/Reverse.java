package arrays;

import java.util.Scanner;

public class Reverse {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of arry");
		int n = sc.nextInt();

		int[] a = new int[n];
		System.out.println("enter the array values");
		for (int k = 0; k < a.length; k++) {
			a[k] = sc.nextInt();
		}
			
			int i = 0;
			int j = a.length - 1;
			
			while (i < j) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				i++;
				j--;
			}
			
		
		System.out.println("-----------------------");
		for (int k =0; k<a.length; k++) {
			System.out.print(a[k]+" ");
		}
		sc.close();
	}
	

}
