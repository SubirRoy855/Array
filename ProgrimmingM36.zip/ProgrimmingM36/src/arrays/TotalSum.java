package arrays;

import java.util.Scanner;

public class TotalSum {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of Array");
		int n = sc.nextInt();
		double[] d = new double[n];
		double sum = 0;
		for (int i = 0; i < d.length; i++) {
			System.out.println("enter the value " + i + " index");
			d[i] = sc.nextDouble();
		}
		System.out.println("....................................");
		for (int i = 0; i < d.length; i++) {
			System.out.println(d[i]);
			sum = sum + d[i];
		}
		System.out.println("sum of all Number :" + sum);
		sc.close();
	}
}
