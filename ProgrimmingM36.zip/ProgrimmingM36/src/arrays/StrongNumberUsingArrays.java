package arrays;

public class StrongNumberUsingArrays {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();

		for (int i = 0; i < ar.length; i++) {
			ar[i] = strongNumber();
	}
		ArrayOperations.displayArray(ar);
	}
		private static int strongNumber() {
		return 0;
	}
		public static void strongNumber(int n) {
			int temp = n;
			int sum = 0;
			while (n != 0) {
				int digit = n % 10;
				int fact = 1;
				for (int i = 1; i <= digit; i++) {
					fact = fact * i;
				}
				sum = sum + fact;
				n = n / 10;
			}
			if (sum == temp)
			{
				System.out.println("strong number");
			}
			else
			{
				System.out.println("not strong number");
			}
			
			
		}

}
