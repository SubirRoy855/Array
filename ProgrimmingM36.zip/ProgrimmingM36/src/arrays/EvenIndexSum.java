package arrays;

import java.util.Scanner;

public class EvenIndexSum {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of Array");
		int n = sc.nextInt();
		int[] d = new int[n];
		int sum = 0;
		for (int i = 0; i < d.length; i++) {
			System.out.println("enter the value " + i + " index");
			d[i] = sc.nextInt();
		}
		System.out.println("....................................");
		for (int i = 0; i < d.length; i++) {
			if (i % 2 == 0) {
				sum = sum + d[i];
			}
			System.out.println("sum of even index: " + sum);
		}
		sc.close();
	}

}
