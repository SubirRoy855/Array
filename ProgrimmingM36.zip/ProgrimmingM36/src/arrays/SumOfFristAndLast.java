package arrays;

import java.util.Scanner;

public class SumOfFristAndLast {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of Array");
		int n=sc.nextInt();
		double[] d = new double[n];
		for (int i = 0; i < d.length; i++) {
			System.out.println("enter the value "+i+" index");
			d[i] = sc.nextDouble();
		}
		System.out.println("....................................");

		for (int i = 0; i < d.length; i++) {
			System.out.println(d[i]);
		}
		double first=d[0];
		double sec=d[d.length-1];
		double sum=first+sec;
		System.out.println("sum is :"+sum);
		
		
		sc.close();
	}

}
