package arrays;

public class MergeTwoArray {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int[] br = ArrayOperations.readArray();
		mergeArray(ar, br);
	}
	public static void mergeArray(int[] ar, int[] br) {
		int[] cr = new int[ar.length + br.length];
		for (int i = 0; i < cr.length; i++) {
			if (i < ar.length) {
				cr[i] = ar[i];
			} else {
				cr[i] = br[i - ar.length];
			}
		}
		ArrayOperations.displayArray(cr);
	}

}
