package arrays;

import java.util.Scanner;

public class Position {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] ar = ArrayOperations.readArray();

		System.out.println("enter the position");
		int position = sc.nextInt();
		position = position- 1;
		System.out.println("enter the element");
		int ele = sc.nextInt();

		insertPosition(ar, position, ele);
		sc.close();
	}

	public static void insertPosition(int[] ar, int position, int ele) {
		int[] br = new int[ar.length + 1];
		
			for (int i = 0; i < br.length; i++) {
				if (i < position)
					br[i] = ar[i];
				else if (i == position)
					br[position] = ele;
				else
					br[i] = ar[i - 1];
			}
			ArrayOperations.displayArray(br);

		}

	}

