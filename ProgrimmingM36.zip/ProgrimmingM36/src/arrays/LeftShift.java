package arrays;

public class LeftShift {
	public static void main(String[] args) {

		int[] ar = ArrayOperations.readArray();
		isLeftShift(ar);
	}

	public static void isLeftShift(int[] ar) {
		int temp = ar[0];
		int j = 1;
		while (j < ar.length ) {
			ar[j - 1] = ar[j];
			j++;
		}
		ar[ar.length - 1] = temp;
		ArrayOperations.displayArray(ar);
	}
}
