package arrays;

public class SecandMaxElement {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int firstmax = ar[0];
		int secandmax = ar[1];

		for (int i = 1; i < ar.length; i++) {
			if (ar[i] > firstmax) {
				secandmax = firstmax;
				firstmax = ar[i];
			} else if (ar[i] > secandmax && ar[i] != firstmax) {
				secandmax = ar[i];

			}
		}
		System.out.println("The secands largest element: " + secandmax);
	}

}
