package arrays;

public class Book {
	public static void main(String[] args) {
	int[] ar=ArrayOperations.readArray();
	
	
	
	ArrayOperations.displayArray(ar);
	}

}
