package arrays;

import java.util.Scanner;

public class RemoveTheElements {

	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the index value: ");
		int index = sc.nextInt();
		isRemove(ar, index);
		sc.close();
	}

	public static void isRemove(int[] ar, int index) {
		int[] br = new int[ar.length - 1];
		if (index < 0 || index > ar.length)
			System.out.println("invalid index");
		else {
			for (int j = 0; j < br.length; j++) {
				if (j < index)
					br[j] = ar[j];

				else if (j >= index)
					br[j] = ar[j + 1];
			}
		}
		ArrayOperations.displayArray(br);

	}

}
