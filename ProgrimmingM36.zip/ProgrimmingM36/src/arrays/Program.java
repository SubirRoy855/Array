package arrays;

public class Program {
	public static void main(String[] args) {
		byte[] b = new byte[5];
		System.out.println("byte: "+b);

		int[] i = new int[3];
		System.out.println("int: "+i);

		short[] s = new short[4];
		System.out.println("short: "+s);

		long[] l = new long[6];
		System.out.println("long; "+l);

		float[] f = new float[5];
		System.out.println("float: "+f);

		double[] d = new double[6];
		System.out.println("double: "+d);

		boolean[] bl = new boolean[5];
		System.out.println("boolean: "+bl);

		String[] st = new String[6];
		System.out.println("String: "+st);

		char[] ch = new char[5];
		System.out.println(ch.toString());
	}

}
