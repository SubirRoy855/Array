package arrays;

public class MargeArrayInShorted {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int[] br = ArrayOperations.readArray();
		isMerge(ar, br);

	}

	public static void isMerge(int[] ar, int[] br) {
		int i = 0;
		int j = 0;
		int k = 0;
		int[] cr = new int[ar.length + br.length];
		while (k < cr.length) {
			if (i < ar.length && j < br.length) {
				if (ar[i] < br[j]) {
					cr[k++] = ar[i++];

				} else {
					cr[k++] = br[j++];
				}
			} else if (j < br.length) {
				cr[k++] = br[j++];

			} else if (i < ar.length) {
				cr[k++] = ar[i++];

			}
		}
		ArrayOperations.displayArray(cr);

	}

}
