package arrays;

public class WithOutNewKeyword {

	public static void main(String[] args) {
		double[] d= {10.2,55.63,89.55,78.93};
		System.out.println(d);
		System.out.println("length of the arrays: "+d.length);
	}
}
