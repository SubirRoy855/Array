package arrays;

public class UsingLooping {
	public static void main(String[] args) {
		int[] a= {10,20,50,602,50,20};
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}

}
