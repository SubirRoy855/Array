package arrays;

public class BubbleSort {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		isBubbleSort(ar);
		ArrayOperations.displayArray(ar);
	}

	public static void isBubbleSort(int[] ar) {
		for (int i = 0; i < ar.length; i++) {
			boolean flag = false;
			for (int j = 0; j < ar.length - 1 - i; j++) {
				if (ar[j] > ar[j + 1]) {
					int temp = ar[j + 1];
					ar[j + 1] = ar[j];
					ar[j] = temp;
					flag = true;
				}
			}
			if (flag == false)
				break;
		}
	}

}
