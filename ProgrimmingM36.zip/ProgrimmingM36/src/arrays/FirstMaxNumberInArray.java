package arrays;

public class FirstMaxNumberInArray {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		int max=ar[0];
		for(int i=1;i<ar.length;i++) {
			if(ar[i]>max) 
				max=ar[i];
		}
		System.out.println("The First Max Elements is: "+max);
	}
	

}
