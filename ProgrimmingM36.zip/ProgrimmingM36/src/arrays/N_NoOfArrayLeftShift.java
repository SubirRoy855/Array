package arrays;

public class N_NoOfArrayLeftShift {
	public static void main(String[] args) {

		int[] ar = ArrayOperations.readArray();
		isnNumberLeftShift(ar);
	}

	public static void isnNumberLeftShift(int[] ar) {
		
		for (int i = 0; i < ar.length; i++) {
			int temp = ar[0];
			int j = 1;
			while (j < ar.length) {
				ar[j - 1] = ar[j];
				j++;
			}
			ar[ar.length - 1] = temp;
			ArrayOperations.displayArray(ar);
		}
	}

}
