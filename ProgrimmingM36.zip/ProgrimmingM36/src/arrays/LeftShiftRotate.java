package arrays;

import java.util.Scanner;

public class LeftShiftRotate {
	public static void main(String[] args) {

		int[] ar = ArrayOperations.readArray();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the Rotate value");
		int r=sc.nextInt();
		isLeftShiftRotate(ar,r);
		sc.close();
	}      

	public static void isLeftShiftRotate(int[] ar,int r) {
		while(r%ar.length>0) {
		int temp = ar[0];
		int j = 1;
		while (j < ar.length ) {
			ar[j - 1] = ar[j];
			j++;
		}
		ar[ar.length - 1] = temp;
		ArrayOperations.displayArray(ar);
		System.out.println();
		System.out.println("******************");
		r--;
	}
		ArrayOperations.displayArray(ar);
	}

}
