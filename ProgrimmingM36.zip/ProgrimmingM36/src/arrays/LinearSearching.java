package arrays;

import java.util.Scanner;

public class LinearSearching {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the elements");
		int elem = sc.nextInt();
		isLinearSearch(ar, elem);
		sc.close();
	}

	public static void isLinearSearch(int[] ar, int elem) {
		boolean flag = false;
		for (int i = 0; i < ar.length; i++) {
			if (ar[i] == elem) {
				System.out.println("elements is found at: " + i);
				flag = true;
			}
		}
		if (flag == false)
			System.out.println("elements is not found");
	}

}
