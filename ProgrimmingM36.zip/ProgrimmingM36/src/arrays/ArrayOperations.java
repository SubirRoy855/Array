package arrays;

import java.util.Scanner;

public class ArrayOperations {
	public static int[] readArray() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int size = sc.nextInt();

		int[] ar = new int[size];

		System.out.println("Enter the array values");
		for (int i = 0; i < ar.length; i++) {
			ar[i] = sc.nextInt();
		}
		return ar;
	}

	public static void displayArray(int[] ar) {
		System.out.print("[");
		for (int i = 0; i < ar.length; i++) {
			System.out.print(ar[i] + " ");
			if (i < ar.length-1)
				System.out.print (",");
		}
		System.out.print("]");

	}

}
