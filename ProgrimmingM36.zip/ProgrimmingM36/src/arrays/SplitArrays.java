package arrays;

public class SplitArrays {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		isSplit(ar);
	}
	public static void isSplit(int[] ar) {
		if(ar.length%2==0) {
			int value=ar.length/2;
			int[] br=new int[value];
			int[] cr=new int[value];
			for(int i=0;i<ar.length;i++) {
				if(i<value) 
					br[i]=ar[i];
				else
					cr[i-value]=ar[i];
			}
		ArrayOperations.displayArray(br);
		ArrayOperations.displayArray(cr);
					
		}
		else
			System.out.println("Array size is not even so cannot split into halves");
	}
}
