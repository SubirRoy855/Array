package arrays;

import java.util.Scanner;

public class TwoSumUserTarged {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the targed value: ");
		int t = sc.nextInt();
		isTarged(ar, t);
		sc.close();

	}

	public static void isTarged(int[] ar, int t) {

		for (int i = 0; i < ar.length; i++) {

			for (int j = 0; j < ar.length; j++) {
				if (t == ar[i] + ar[j]) {
					System.out.print("[" + i + ",");

					System.out.print(j + "" + "]");
				}
			}

		}

	}
}
