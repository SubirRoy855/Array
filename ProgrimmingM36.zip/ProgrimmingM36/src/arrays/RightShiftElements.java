package arrays;

public class RightShiftElements {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		isRightShift(ar);
	}

	public static void isRightShift(int[] ar) {
		int temp = ar[ar.length - 1];
		int j = ar.length - 2;
		while (j >= 0) {
			ar[j + 1] = ar[j];
			j--;
		}
		ar[0] = temp;
		ArrayOperations.displayArray(ar);
	}

}
