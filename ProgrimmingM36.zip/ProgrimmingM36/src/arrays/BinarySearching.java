package arrays;

import java.util.Scanner;

public class BinarySearching {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the elements");
		int elem=sc.nextInt();
		isBinarySearch(ar,elem);
		sc.close();
	}
	public static void 	isBinarySearch(int[] ar,int elem) {
		boolean flag=false;
		int l=0;
		int r=ar.length-1;
		while(l<=r) {
			int mid=(l+r)/2;
			if(elem==ar[mid]) {
				flag=true;
				System.out.println("it's elements is: "+mid);
				break;
			}
			else if(elem>ar[mid])
				l=mid+1;
			else if(elem<ar[mid])
				r=mid-1;
				
		}
		if(flag==false)
			System.out.println("elements not found");
		
	}

}
