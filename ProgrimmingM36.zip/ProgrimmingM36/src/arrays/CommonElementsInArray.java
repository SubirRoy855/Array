package arrays;

public class CommonElementsInArray {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		int[] br=ArrayOperations.readArray();
		isCommon(ar,br);
		
	}
	public static void isCommon(int[] ar,int[] br) {
		for(int i=0;i<ar.length;i++) {
			boolean flag=false;
			for(int j=0;j<br.length;j++) {
				if(ar[i]==br[j]) {
					flag=true;
					br[j]=0;
				}
			}
			if(flag==true) {
				System.out.println(ar[i]);
			}
		}
	}

}
