package arrays;

public class LengthOfArrays {
		public static void main(String[] args) {
			byte[] b = new byte[5];
			System.out.println(b.length);

			int[] i = new int[3];
			System.out.println(i.length);

			short[] s = new short[4];
			System.out.println(s.length);

			long[] l = new long[6];
			System.out.println("long; "+l.length);

			float[] f = new float[5];
			System.out.println("float: "+f.length);

			double[] d = new double[6];
			System.out.println("double: "+d.length);

			boolean[] bl = new boolean[5];
			System.out.println("boolean: "+bl.length);

			String[] st = new String[6];
			System.out.println("String: "+st.length);

			char[] ch = new char[5];
			System.out.println("char: "+ch.length);
		}

	}



