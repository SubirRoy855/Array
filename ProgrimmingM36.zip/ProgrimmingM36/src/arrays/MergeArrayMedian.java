package arrays;

public class MergeArrayMedian {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int[] br = ArrayOperations.readArray();
		int median=isMerge(ar, br);
		System.out.println(median);

	}

	public static int isMerge(int[] ar, int[] br) {
		int i = 0;
		int j = 0;
		int k = 0;
		int[] cr = new int[ar.length + br.length];
		while (k < cr.length) {
			if (i < ar.length && j < br.length) {
				if (ar[i] < br[j]) {
					cr[k++] = ar[i++];

				} else {
					cr[k++] = br[j++];
				}
			} else if (j < br.length) {
				cr[k++] = br[j++];

			} else if (i < ar.length) {
				cr[k++] = ar[i++];

			}
		}
		int size=cr.length;
		if(size%2==0)
			return (cr[size/2]+cr[size/2-1])/2;
		else
			return cr[size/2];
		}

	}


