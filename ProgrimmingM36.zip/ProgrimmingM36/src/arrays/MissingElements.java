package arrays;

public class MissingElements {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		isMissing(ar);

	}

	public static void isMissing(int[] ar) {
		for (int i = 0; i < ar.length-1; i++) {
			
			int first = ar[i];
			int secand = ar[i + 1];
			for (int j = first + 1; j < secand; j++) {
				System.out.println(j + " ");
			}
		}
	}

}
