package arrays;

public class CommonElementes {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int[] br = ArrayOperations.readArray();
		isCommonElements(ar, br);
	}

	public static void isCommonElements(int[] ar, int[] br) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < br.length; j++) {
				if (ar[i] == br[j]) {
					System.out.println(ar[i] + " it's a common elements");
				}

			}

		}
	}
}
