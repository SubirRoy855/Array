package arrays;

public class FristMinNumber {
	public static void main(String[] args) {
		int[] ar=ArrayOperations.readArray();
		int min=ar[0];
		for(int i=1;i<ar.length;i++) {
			if(ar[i]<min)
			min=ar[i];
		}
		System.out.println("The first min element is: "+min);
	}

}
