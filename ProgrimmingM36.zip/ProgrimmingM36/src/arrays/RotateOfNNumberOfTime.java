package arrays;

import java.util.Scanner;

public class RotateOfNNumberOfTime {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the rotation values");
		int r = sc.nextInt();
		isRotation(ar, r);
		sc.close();
	}

	public static void isRotation(int[] ar, int r) {

		while (r%ar.length > 0) {

			int temp = ar[ar.length - 1];
			int j = ar.length - 2;
			while (j >= 0) {
				ar[j + 1] = ar[j];
				j--;
			}
			ar[0] = temp;
			ArrayOperations.displayArray(ar);
			System.out.println();
			System.out.println("-------------------");
			r--;
		}
		ArrayOperations.displayArray(ar);
	}

}
