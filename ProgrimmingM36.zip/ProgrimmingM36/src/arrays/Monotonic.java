package arrays;

public class Monotonic {
	public static void main(String[] args) {

		int[] ar = ArrayOperations.readArray();
		isMonotonic(ar);
	}

	public static void isMonotonic(int[] ar) {

		boolean flag = false;
		boolean flag2 = false;

		for (int i = 1; i < ar.length; i++) {

			if (ar[i] > ar[i - 1]) {
				flag = true;
			} else if (ar[i] < ar[i - 1]) {
				flag2 = true;
			}
		}
		if (flag == false || flag2 == false)
			System.out.println("it's  a monotomnic array");
		else
			System.out.println("it is not monotonic array");
	}

}
