package arrays;

public class EvenOrOddMetheod {
	public static int[] countArray(int[] br) {
		int oc=0;
		int ec=0;
		for(int i=0;i<br.length;i++) {
			if(br[i]%2==0) {
				ec++;
			}else {
				oc++;
			}
		}
		int[] result=new int[2];
		result[0]=ec;
		result[1]=oc;
		return result;
	}
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		int[] cr=countArray(ar);
		System.out.println("even count is: "+cr[0]);
		System.out.println("odd count is: "+cr[1]);
		}

}
