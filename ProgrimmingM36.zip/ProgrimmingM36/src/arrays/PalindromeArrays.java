package arrays;

import java.util.Scanner;

public class PalindromeArrays {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of arry");
		int n = sc.nextInt();

		char[] ch = new char[n];

		System.out.println("enter the char value ");

		for (int i = 0; i < ch.length; i++) {
			ch[i] = sc.next().charAt(0);
		}

		int i = 0;
		int j = ch.length - 1;
		boolean flag = false;
		while (i <= j) {
			if(ch[i]==ch[j]) {
			i++;
			j--;
			}
			else {
				flag=true;
			break;
			}
		}
		if (flag == false) {
			System.out.println("it is Palindrome character array");
		} else {
			System.out.println("it is not palindrome character");
		}
		sc.close();
	}
}
