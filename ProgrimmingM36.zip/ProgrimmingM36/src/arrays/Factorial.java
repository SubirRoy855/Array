package arrays;

public class Factorial {
	public static void main(String[] args) {
		int[] ar = ArrayOperations.readArray();
		for (int i = 0; i < ar.length; i++) {
			isFactorial(ar[i]);
		}

	}

	public static void isFactorial(int n) {
		int fact = 1;
		for (int i = 1; i <= n; i++) {
			fact = fact * i;
		}
		System.out.println("factorial of " + n + " is " + fact);
	}

}
