package arrays;

import java.util.Scanner;

public class InsertUserInput {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] ar = ArrayOperations.readArray();

		System.out.println("enter the index");
		int index = sc.nextInt();
		System.out.println("enter the element");
		int ele = sc.nextInt();

		insertArray(ar, index, ele);
		sc.close();
	}

	public static void insertArray(int[] ar, int index, int ele) {
		int[] br = new int[ar.length + 1];
		if (index < 0 || index == ar.length || index > ar.length) {
			System.out.println("invlaid index");
		} else {
			for (int i = 0; i < br.length; i++) {
				if (i < index)
					br[i] = ar[i];
				else if (i == index)
					br[index] = ele;
				else
					br[i] = ar[i - 1];
			}
			ArrayOperations.displayArray(br);
		}

	}

}
