package numberFormat;

import java.util.Scanner;

public class DisariumNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		int count=0;
		int temp=n;
		int temp2=n;
		int sum=0;
		while(n!=0)
		{
			int digit=n%10;
			count++;
			n=n/10;
		}
		while(temp!=0)
		{
			int digit=temp%10;
			int pow=1;
			for(int i=1;i<=count;i++)
			{
				pow=pow*digit;
			}
			sum=sum+pow;
			temp=temp/10;
			count--;
		}
		if(temp2==sum)
			System.out.println("it is a Disarium number");
		else
			System.out.println("it's not a Disarium number");
		sc.close();
	}

}
