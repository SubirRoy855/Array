package numberFormat;

import java.util.Scanner;

public class TowDigitNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int n = sc.nextInt();
		if ((n > 9 && n < 100) || (n < -9 && n > -100)) {
			System.out.println("Its two digit number");
		} else {
			System.out.println("Its not a two digit number");
		}
		sc.close();
	}

}
	