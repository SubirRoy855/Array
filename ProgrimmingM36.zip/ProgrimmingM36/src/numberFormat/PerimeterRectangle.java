package numberFormat;

import java.util.Scanner;

public class PerimeterRectangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value length");
		double length=sc.nextDouble();
		System.out.println("Enter the value breath");
		double breath=sc.nextDouble();
		double perimeterRectangle=2*(length*breath);
		System.out.println("PerimeterRectangle is :"+perimeterRectangle);
		sc.close();
	}

}
