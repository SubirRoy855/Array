package numberFormat;

import java.util.Scanner;

public class MpowerN {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the m value");
		int m = sc.nextInt();
		System.out.println("enter the n value");
		int n = sc.nextInt();
		int pow = 1;

		for (int i = 1; i <= n; i++) {

			 pow = pow * m;

		}
		System.out.println(m+" power"+n+"is :"+pow);
		sc.close();
	}

}
