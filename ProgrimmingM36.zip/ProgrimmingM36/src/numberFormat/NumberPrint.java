package numberFormat;

import java.util.Scanner;

public class NumberPrint {
	public static void main(String[] args) {
		System.out.println("enter the number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i=1;
		while(n>=i)
		{
			System.out.println(n);
			n--;
		}
		}
		
	}


