package numberFormat;

import java.util.Scanner;

public class HappyNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value");
		int n = sc.nextInt();
		while (n != 1 && n != 4) {
			int sum = 0;
			while (n != 0) {
				int digit = n % 10;
				int sqr = digit * digit;
				sum = sum + sqr;
				n = n / 10;
			}
			n = sum;
		}
		if (n == 1)
			System.out.println("it's happy number");
		else
			System.out.println("unhappy number");
		sc.close();

	}

}
