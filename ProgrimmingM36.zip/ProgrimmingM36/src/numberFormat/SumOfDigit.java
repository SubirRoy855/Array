package numberFormat;

import java.util.Scanner;

public class SumOfDigit {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the valu");
		int n = sc.nextInt();
		int sum = 0;// initialization
		while (n != 0)// condition
		{
			int last_digit = n % 10;
			sum = sum + last_digit;
			n = n / 10;// update
		}
		System.out.println("Sum of valu :" + sum);
		sc.close();
	}

}
