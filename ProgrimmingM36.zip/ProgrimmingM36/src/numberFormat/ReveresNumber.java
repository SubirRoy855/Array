package numberFormat;

import java.util.Scanner;

public class ReveresNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int n=sc.nextInt();
		int reveres=0;//intialization
		while(n!=0)//condition
		{
			int digit=n%10;
			reveres=reveres*10+digit;
			n=n/10;//update
		}
		System.out.println("the reveres number is : "+reveres);
		sc.close();
	}

}
