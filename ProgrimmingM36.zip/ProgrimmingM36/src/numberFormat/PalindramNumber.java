package numberFormat;

import java.util.Scanner;

public class PalindramNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int n=sc.nextInt();
		int reveres=0;//intialization
		int pal=n;
		while(n!=0)//condition
		{
			int digit=n%10;
			reveres=reveres*10+digit;
			n=n/10;//update
		}
		if(reveres==pal)
		System.out.println("it is a palindram number");
		else
		System.out.println("it is a not palindram number");
		sc.close();
	}

}
