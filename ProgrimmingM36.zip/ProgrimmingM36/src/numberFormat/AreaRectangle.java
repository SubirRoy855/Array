package numberFormat;

import java.util.Scanner;

public class AreaRectangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length value");
		double length=sc.nextDouble();
		System.out.println("Enter the breath value");
		double breath=sc.nextDouble();
		double areaRectangle=length*breath;
		System.out.println("AreaRectangle is :"+areaRectangle);

		
		sc.close();
	}

}
