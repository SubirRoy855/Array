package numberFormat;

import java.util.Scanner;

public class PronicNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the valu");
		int n = sc.nextInt();
		boolean flag = false;

		for (int i = 1; i <= n; i++) {
			if (i * (i + 1) == n) {
				System.out.println("it's pronic numbner");
				flag = true;
				break;

			}
		}

		if (flag == false)
			System.out.println("it's not pronic number");
		sc.close();
	}
}
