package numberFormat;

import java.util.Scanner;

public class DuckNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sc.nextInt();
		int count = 0;
		while (n != 0) {
			int digit = n % 10;
			if (digit == 0)
				count++;
			n = n / 10;
		}
		if (count > 0)
			System.out.println("it's a duck number");
		else
			System.out.println("it's not a duck number");
		sc.close();

	}
}
