package numberFormat;

import java.util.Scanner;

public class OctalToDecimal {
	public static void main(String[] args) {
		System.out.println("Enter the Number");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int count = 0;
		int sum = 0;
		while (n != 0) {
			int digit = n % 10;
			digit = digit * power(8, count);
			sum=sum+digit;
			count++;
			n = n / 10;
		}
		System.out.println("it's decimal representation number:" + sum);
		sc.close();
	}

	public static int power(int base, int exp) {
		int prod = 1;

		for (int i = 1; i <= exp; i++) {
			prod = prod * base;
		}
		return prod;
	}
}
