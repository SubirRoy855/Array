package numberFormat;

import java.util.Scanner;

public class Octal {
	public static void main(String[] args) {
		System.out.println("Enter the value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String oct="";
		while(n!=0)
		{
			int rem=n%8;
			oct=rem+oct;
			n=n/2;
		}
		System.out.println("it's binary representary number:" +oct);
	}
}
