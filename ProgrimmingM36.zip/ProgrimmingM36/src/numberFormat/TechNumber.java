package numberFormat;

import java.util.Scanner;

public class TechNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sc.nextInt();
		int count = 0;
		int temp = n;
		while (n != 0) {
			int digit = n % 10;
			count++;
			n = n / 10;
		}
		int dig = 1;
		for (int i = 1; i <= count / 2; i++) {
			dig = dig * 10;
		}
		int lastdigit = temp % dig;
		int firstdigit = temp / dig;
		int sum = lastdigit + firstdigit;
		int sqr = sum * sum;
		if (temp == sqr) {
			System.out.println("it's a tech number");
		} else
			System.out.println("it's not a tech number");

		sc.close();
	}
}
