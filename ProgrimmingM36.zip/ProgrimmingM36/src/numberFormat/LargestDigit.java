package numberFormat;

import java.util.Scanner;

public class LargestDigit {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		int large=n%10;
		while(n!=0)
		{
			int digit=n%10;
			if(digit>large)
			{
				large=digit;
			}
			n=n/10;
		}
		System.out.println("Largest digit is "+large);
		sc.close();
	}
	

}


