package numberFormat;

import java.util.Scanner;

public class EvenOddForLoop {
		public static void main(String[] args) {
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter the number");
			int n=sc.nextInt();
			for(;n!=0;n=n/10)
			{
				int d=n%10;
				if (d%2==0)
				{
					System.out.println(d +"     is even");
				}
				else
				{
					System.out.println(d+"    is odd");
				}
			
				
				
			}
			sc.close();
		}

	}



