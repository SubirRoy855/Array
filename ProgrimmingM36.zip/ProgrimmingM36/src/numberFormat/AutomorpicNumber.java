package numberFormat;

import java.util.Scanner;

public class AutomorpicNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int n = sc.nextInt();
		boolean flag = false;
		int sqr = n * n;
		while (n != 0) {
			if (n % 10 == sqr % 10) {
				n = n / 10;
				sqr = sqr / 10;
			} else {

				flag = true;
				break;

			}

		}
		if (flag == false)
			System.out.println("it is  Automorphic num");
		else
			System.out.println("it is  not Automorphic num");
		sc.close();
	}
}
