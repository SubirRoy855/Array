package numberFormat;

import java.util.Scanner;

public class XylemOrPhloemNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		int sum=0;
		while(n!=0)
		{
			int last=n%10;
			n=n/10;
		}
		while(n>9)
		{
			int digit1=n%10;
		}
	
	}

}
