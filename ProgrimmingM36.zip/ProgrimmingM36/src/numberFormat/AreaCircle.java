package numberFormat;

import java.util.Scanner;

public class AreaCircle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		double n=sc.nextDouble();
		double area=3.14*n*n;
		System.out.println("area of circle :"+area);
		sc.close();
	}

}
