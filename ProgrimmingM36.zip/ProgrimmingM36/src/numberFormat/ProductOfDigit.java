package numberFormat;

import java.util.Scanner;

public class ProductOfDigit {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int n=sc.nextInt();
		int prod=1;//initialization
		while(n!=0)//condition
		{
			int last_digit=n%10;
			prod=prod*last_digit;
			n=n/10;//update
		}
		System.out.println("Product of valu :"+prod);
		sc.close();
	}

}
