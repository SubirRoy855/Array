package numberFormat;

import java.util.Scanner;

public class CountEvenCountOdd {
	public static void main(String[] args) {
		System.out.println("Enter the value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int evenCount=0;
		int oddCount=0;
		while(n!=0)
		{
			int d=n%10;
			if(d%2==0) 
			evenCount++;
			else
		oddCount++;
			n=n/10;}
		System.out.println(evenCount+" is a even");
		System.out.println(oddCount+" is a odd");
		sc.close();
	}

}
