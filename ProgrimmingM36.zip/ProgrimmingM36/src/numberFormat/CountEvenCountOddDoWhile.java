package numberFormat;

import java.util.Scanner;

public class CountEvenCountOddDoWhile {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int n=sc.nextInt();
		int evenCount=0;
		int oddCount=0;
		do
		{
			int d=n%10;
			if(d%2==0)
			{
				evenCount++;
			}
			else
			{
				oddCount++;
			}
			n=n/10;
		}
		while(n!=0);
		System.out.println(evenCount+"is a even");
		System.out.println(oddCount+"is odd");
	sc.close();
	}

}
