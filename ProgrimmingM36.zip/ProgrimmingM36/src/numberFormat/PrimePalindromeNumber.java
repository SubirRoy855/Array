package numberFormat;
import java.util.Scanner;

public class PrimePalindromeNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int n=sc.nextInt();
		int count=0;
		
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				count++;
				break;
				
			}		
		}
		if(count==0)
		{
			int rev=0;
			int temp=0;
			while(n!=0)
			{
				int digit=n%10;
				rev=rev*10+digit;
				n=n/10;
			}
			if(temp==rev)
				System.out.println("It is prime palimdrome number");
			else
				System.out.println("It is not prime palimdrome number");
		}
		else
			System.out.println("it is not prime number");
		sc.close();
	}

}
