package numberFormat;

import java.util.Scanner;

public class EevenOddDigite {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		while(n!=0)
		{
			int d=n%10;
			if (d%2==0)
			{
				System.out.println(d +"     is even");
			}
			else
			{
				System.out.println(d+"    is odd");
			}
			n=n/10;
			
			
		}
		sc.close();
	}

}
