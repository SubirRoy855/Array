package numberFormat;

import java.util.Scanner;

public class SpicalTwoDigitNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sc.nextInt();
		int first = n / 10;
		int last = n % 10;
		int sum = first + last;
		int prod = first * last;
		int value = sum + prod;
		if (value == n)
			System.out.println("it is a spical two digit number");
		else
			System.out.println("it is  not a spical two digit number");
		sc.close();
	}

}
