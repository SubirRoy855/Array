package string;

import java.util.Scanner;

public class PalindromString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sting: ");
		String s = sc.nextLine();
		char[] ch = s.toCharArray();
		int i = 0;
		int j = ch.length - 1;
		boolean flag = false;
		while (i < j) {
			if (ch[i] == ch[j]) {
				i++;
				j--;
			}
			 else
				flag = true;
			break;
		}
		if (flag == false)
			System.out.println("it is palindrom string");
		else
			System.out.println("it in not palindrom string");
		sc.close();

	}

}
