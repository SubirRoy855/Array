package string;

import java.util.Scanner;

public class ConvertToLowerToUpperCase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sting: ");
		String s = sc.nextLine();
		char[] ch = s.toCharArray();
		String s1 = "";
		for (int i = 0; i < ch.length; i++) {

			s1 = s1 + (char) (ch[i] - 32);

		}
		System.out.println("Upper Case String is: "+s1);
		sc.close();
	}

}
