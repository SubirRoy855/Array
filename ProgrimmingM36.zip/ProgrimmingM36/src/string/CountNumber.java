package string;

import java.util.Scanner;

public class CountNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string value: ");
		String s = sc.nextLine();
		
		int count = 0;
		
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) >= 48 && s.charAt(i) <= 57) {
				count++;
			}
		}
		if (count == 0) {
			System.out.println("No number in string");
		} else {
			System.out.println("Number of count: " + count);
		}
		sc.close();

	}

}
