package string;//22

import java.util.Scanner;

public class PangramString {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string: ");
		String s=sc.nextLine();
		boolean result=isPangram(s);
		if(result==true)
			System.out.println("it is a pangram string");
		else
			System.out.println("it is not pangram string");
		sc.close();
	}
	public static boolean isPangram(String s) {
		int[] count=CountOfAllChar.isAllFrequency(s);//method call
		for(int i=0;i<count.length;i++) {
			if(count[i]==0) 
				return false;
		}
		return true;
	}

}
