package string;

public class Program1 {

	public static void main(String[] args) {

		String s1="hello";
		String s2="hello";
		System.out.println(s1.hashCode());//it's provide the hello unique number
		System.out.println(s2.hashCode());
		
		String s3=new String("hello");
		String s4=new String("hello");
		System.out.println(s3==s4);//it's return only address o/p=false
	}

}
